package quizarraylist;

public class Mascota {
    
    private String nombre;
    private int edad;
    private int especie;
    private String especie1;
    
    
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public int getEdad() {
        return edad;
    }
    public void setEdad(int edad) {
        this.edad = edad;
    }
    public int getEspecie() {
        return especie;
    }
    public void setEspecie(int especie) {
        this.especie = especie;
    }

    public Mascota() {
    }
    
    public String datosMascotas(){
        if(especie==1){
            especie1="Perro";
        }
        if(especie==2){
            especie1="Gato";
        }
        if(especie==3){
            especie1="Cocodrilo";
        }
        if(especie==4){
            especie1="Hamster";
        }
        if(especie==5){
            especie1="Serpiente";
        }
        if(especie==6){
            especie1="Tarantula";
        }
        if(especie==7){
            especie1="Caballo";
        }
       return "Nombre: " + nombre + "\n"
                + "Edad: " + edad + "\n"
                + "especie: " + especie1;
    }
    
    public String mascotasAdoptadas(){
        if(especie==1){
            especie1="Perro";
        }
        if(especie==2){
            especie1="Gato";
        }
        if(especie==3){
            especie1="Cocodrilo";
        }
        if(especie==4){
            especie1="Hamster";
        }
        if(especie==5){
            especie1="Serpiente";
        }
        if(especie==6){
            especie1="Tarantula";
        }
        if(especie==7){
            especie1="Caballo";
        }
        return "Nombre: " + nombre + "\n"
                + "Edad: " + edad + "\n"
                + "especie: " + especie1;
    }
}
