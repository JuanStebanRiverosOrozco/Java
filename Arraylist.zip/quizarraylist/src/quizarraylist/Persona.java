/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package quizarraylist;
public class Persona {
    
    private String nombreP;
    private int edad;
    private long DNI;
    private long celular;
    private String nombreM;

    public String getNombreP() {
        return nombreP;
    }
    public void setNombreP(String nombreP) {
        this.nombreP = nombreP;
    }
    public int getEdad() {
        return edad;
    }
    public void setEdad(int edad) {
        this.edad = edad;
    }
    public long getDNI() {
        return DNI;
    }
    public void setDNI(long DNI) {
        this.DNI = DNI;
    }
    public long getCelular() {
        return celular;
    }
    public void setCelular(long celular) {
        this.celular = celular;
    }
    public String getNombreM() {
        return nombreM;
    }
    public void setNombreM(String nombreM) {
        this.nombreM = nombreM;
    }
    
    
    public Persona() {
    }
    
    
    
    public String datosDueño(){
        return "Nombre: "+nombreP+" \n"
                + "edad: "+ edad +"\n"
                + "Documento identidad: "+DNI+"\n"
                + "Celular: "+ celular +"\n"
                + "Nombre mascota: "+nombreM +"\n";
         
    }
}
