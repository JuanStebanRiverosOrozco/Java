
package quizarraylist;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.ArrayList;
import java.util.List;

public class QuizArrayList {

    static ArrayList<Mascota> m = new ArrayList<>();
    static ArrayList<Mascota> ma = new ArrayList<>();
    static ArrayList<Persona> p = new ArrayList<>();

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> MENU());
    }

    public static void MENU() {
        JFrame frame = new JFrame("Quiz con ArrayList");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 500);
        frame.setLayout(new BorderLayout());

        JPanel menuPanel = new JPanel(new GridLayout(10, 10, 8, 8));
        frame.add(menuPanel, BorderLayout.CENTER);

        JButton[] buttons = new JButton[8];
        buttons[0] = createMenuButton("Registrar mascota", e -> registrarMascota());
        buttons[1] = createMenuButton("Ver todas las mascotas", e -> verTodasLasMascotas());
        buttons[2] = createMenuButton("Ver mascota por especie", e -> verMascotaPorEspecie());
        buttons[3] = createMenuButton("Eliminar mascota", e -> eliminarMascota());
        buttons[4] = createMenuButton("Actualizar mascota", e -> actualizarMascota());
        buttons[5] = createMenuButton("Adoptar mascota", e -> adoptarMascota());
        buttons[6] = createMenuButton("Ver mascotas adoptadas", e -> verMascotasAdoptadas());
        buttons[7] = createMenuButton("Salir", e -> System.exit(0));

        for (JButton button : buttons) {
         button.setFont(new Font ("Times New Roman",Font.BOLD,20));
         button.setBackground(Color.LIGHT_GRAY);
            menuPanel.add(button);
        }

        frame.setVisible(true);
    }

    private static JButton createMenuButton(String text, ActionListener actionListener) {
        JButton button = new JButton(text);
        button.addActionListener(actionListener);

        return button;
    }

    private static void registrarMascota() {
        Mascota mascota = new Mascota();
        mascota.setNombre(JOptionPane.showInputDialog(null, "Ingrese el nombre de la mascota:"));
        mascota.setEdad(Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese la edad de la mascota:")));
        int especie = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese la especie de la mascota:\n1. Perro\n2. Gato\n3. Cocodrilo\n4. Hamster\n5. Serpiente\n6. Tarantula\n7. Caballo"));
        mascota.setEspecie(especie);

        if (especie > 7 || especie < 1) {
            JOptionPane.showMessageDialog(null, "Vuelva a registrar la mascota.");
            registrarMascota();
            return;
        }


        m.add(mascota);
        JOptionPane.showMessageDialog(null, "Mascota registrada con éxito.");
    }

    private static void verTodasLasMascotas() {
        mostrarTablaMascotas(m, "Todas las mascotas");
    }

    private static String obtenerNombreEspecie(int especie) {
        return switch (especie) {
            case 1 -> "Perro";
            case 2 -> "Gato";
            case 3 -> "Cocodrilo";
            case 4 -> "Hamster";
            case 5 -> "Serpiente";
            case 6 -> "Tarantula";
            case 7 -> "Caballo";
            default -> "Desconocida";
        };
    }



    private static void mostrarTablaMascotas(List<Mascota> mascotas, String titulo) {
        String[] columnas = {"Nombre", "Edad", "Especie"};
        Object[][] datos = new Object[mascotas.size()][7];

        int i = 0;
        for (Mascota mascota : mascotas) {
            datos[i][0] = mascota.getNombre();
            datos[i][1] = mascota.getEdad();
            datos[i][2] = obtenerNombreEspecie(mascota.getEspecie());
            i++;
        }

        JTable table = new JTable(datos, columnas);
        JScrollPane scrollPane = new JScrollPane(table);
        JOptionPane.showMessageDialog(null, scrollPane, titulo, JOptionPane.PLAIN_MESSAGE);
    }

    private static void verMascotaPorEspecie() {
        int especie = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese el número de especie para ver:\n1. Perro\n2. Gato\n3. Cocodrilo\n4. Hamster\n5. Serpiente\n6. Tarantula\n7. Caballo"));
        List<Mascota> mascotasPorEspecie = new ArrayList<>();
        for (Mascota mascota : m) {
            if (mascota.getEspecie() == especie) {
                mascotasPorEspecie.add(mascota);
            }
        }
        mostrarTablaMascotas(mascotasPorEspecie, "Mascotas de la especie seleccionada");
    }

    private static void eliminarMascota() {
        String nombreMascota = JOptionPane.showInputDialog(null, "Ingrese el nombre de la mascota que desea eliminar:");
        boolean mascotaEliminada = false;
        for (Mascota mascota : m) {
            if (nombreMascota.equalsIgnoreCase(mascota.getNombre())) {
                m.remove(mascota);
                mascotaEliminada = true;
                JOptionPane.showMessageDialog(null, "Mascota eliminada con éxito.");
                break;
            }
        }
        if (!mascotaEliminada) {
            JOptionPane.showMessageDialog(null, "La mascota no fue encontrada.");
        }
    }

    private static void actualizarMascota() {
        String nombreMascota = JOptionPane.showInputDialog(null, "Ingrese el nombre de la mascota que desea actualizar:");
        boolean mascotaActualizada = false;
        Mascota mascotaExistente = null;

        for (Mascota mascota : m) {
            if (nombreMascota.equalsIgnoreCase(mascota.getNombre())) {
                mascotaExistente = mascota;
                break;
            }
        }

        if (mascotaExistente != null) {
            mascotaExistente.setNombre(JOptionPane.showInputDialog(null, "Ingrese el nuevo nombre de la mascota:"));
            mascotaExistente.setEdad(Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese la nueva edad de la mascota:")));
            int especie = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese la nueva especie de la mascota:\n1. Perro\n2. Gato\n3. Cocodrilo\n4. Hamster\n5. Serpiente\n6. Tarantula\n7. Caballo"));
            mascotaExistente.setEspecie(especie);

            JOptionPane.showMessageDialog(null, "Mascota actualizada con éxito.");
        } else {
            JOptionPane.showMessageDialog(null, "La mascota no fue encontrada.");
        }
    }

    private static void adoptarMascota() {
        String nombreMascota = JOptionPane.showInputDialog(null, "Ingrese el nombre de la mascota que desea adoptar:");
        boolean mascotaAdoptada = false;
        for (Mascota mascota : m) {
            if (nombreMascota.equalsIgnoreCase(mascota.getNombre())) {
                m.remove(mascota);
                mascotaAdoptada = true;

                Persona persona = new Persona();
                persona.setNombreP(JOptionPane.showInputDialog(null, "Ingrese el nombre del dueño:"));
                persona.setEdad(Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese la edad del dueño:")));
                persona.setDNI(Long.parseLong(JOptionPane.showInputDialog(null, "Ingrese el documento de identidad del dueño:")));
                persona.setCelular(Long.parseLong(JOptionPane.showInputDialog(null, "Ingrese el número de celular del dueño:")));
                persona.setNombreM(nombreMascota);

                JOptionPane.showMessageDialog(null, "La mascota " + nombreMascota + " fue adoptada.");
                ma.add(mascota);
                p.add(persona);
                break;
            }
        }
        if (!mascotaAdoptada) {
            JOptionPane.showMessageDialog(null, "La mascota no fue encontrada.");
        }
    }

    private static void verMascotasAdoptadas() {
        String[] columnas = {"Nombre de la mascota", "Edad", "Especie", "Nombre del dueño", "Edad", "Cedula", "Número de celular"};
        Object[][] datos = new Object[ma.size()][8];

        int i = 0;
        for (Mascota mascota : ma) {
            datos[i][0] = mascota.getNombre();
            datos[i][1] = mascota.getEdad();
            datos[i][2] = obtenerNombreEspecie(mascota.getEspecie());
               for (Persona persona : p) {
                if (persona.getNombreM().equals(mascota.getNombre())) {
                    datos[i][3] = persona.getNombreP();
                    datos[i][4] = persona.getEdad();
                    datos[i][5] = persona.getDNI();
                    datos[i][6] = persona.getCelular();
                    break;
                }
            }
            i++;
        }

        JTable table = new JTable(datos, columnas);
        JScrollPane scrollPane = new JScrollPane(table);
        JOptionPane.showMessageDialog(null, scrollPane, "Mascotas adoptadas", JOptionPane.PLAIN_MESSAGE);
    }

}