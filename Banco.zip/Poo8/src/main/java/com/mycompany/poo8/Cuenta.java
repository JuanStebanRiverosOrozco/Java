package com.mycompany.poo8;

public class Cuenta {

   protected long ncuenta=100000;
   private long DNI;
   private double sactual;
   private double ianual;
   
   public Cuenta(){
    
    }
   public Cuenta(long DNI,double sactual, double ianual){
       this.DNI=0;
       this.sactual=0;
       this.ianual=0;
   }
       public long getNcuenta() {
        return ncuenta;
    }

    public long getDNI() {
        return DNI;
    }

    public void setDNI(long DNI) {
        this.DNI = DNI;
    }

    public double getSactual() {
        return sactual;
    }

    public void setSactual(double sactual) {
        this.sactual = sactual;
    }

    public double getIanual() {
        return ianual;
    }

    public void setIanual(double ianual) {
        this.ianual = ianual;
    }

    public void actusaldo(){
        sactual=sactual+(((ianual/365)/100)*sactual);
        
    }
    public void ingresar(double cantidad){
        sactual=sactual+cantidad;
        
    }
    public void retirar(double cantidad){
        sactual=sactual-cantidad;
    }  
    public String datos(){
       return "Número de Cuenta:"+ncuenta+"\n"+
               "DNI:"+DNI+"\n"+
               "Saldo Actual:"+sactual+"\n"+
               "Interes Anual:"+ianual+"\n";
    }       
}

