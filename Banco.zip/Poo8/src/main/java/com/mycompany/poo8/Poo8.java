package com.mycompany.poo8;

import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Poo8 {

    public static void main(String[] args) {
    menu();  
}
    static ArrayList<Cuenta> Cuentas=new ArrayList<>();

    public static void menu(){
         int opc;
         long cedula;
         double dinero;
         boolean band=true;
         
         Cuenta usuarios=new Cuenta();         
         opc=Integer.parseInt(JOptionPane.showInputDialog(null, """
                                                                Banco de Juan y Danna:
                                                                1. Registrar usuario:
                                                                2. Ingresar dinero:
                                                                3. Retirar dinero:
                                                                4. Ver cuenta:
                                                                5. Ver todas las cuentas:
                                                                6. Salir:
                                                                """));
         switch(opc){
             case 1 -> {
                 usuarios.setDNI(Long.parseLong(JOptionPane.showInputDialog(null, "Digite el DNI: ")));
                 usuarios.setSactual(Double.parseDouble(JOptionPane.showInputDialog(null,"Digite el Saldo Actual: ")));
                 usuarios.setIanual(Double.parseDouble(JOptionPane.showInputDialog(null,"Digite el Interes Anual: ")));
                 
                 Cuentas.add(usuarios);
                 usuarios.ncuenta=usuarios.ncuenta+Cuentas.size();
                 
                 
                 JOptionPane.showMessageDialog(null, "El usuario ha sido registrado.");
                 menu();
                 break;
                         }
             case 2 -> {
                 cedula=Long.parseLong(JOptionPane.showInputDialog(null, "Digite la cédula: "));
                 for (Cuenta Cuenta:Cuentas){
                     if(cedula==Cuenta.getDNI()){
                         dinero=Double.parseDouble(JOptionPane.showInputDialog(null,"Digite el dinero que va a ingresar:"));
                         Cuenta.ingresar(dinero);
                         Cuenta.actusaldo();
                         
                         JOptionPane.showMessageDialog(null,"El dinero ha sido consignado.");
                         band=true;
                         menu();
                     }
                     else{
                         band=false;
                     }
                 }
                 if(band==false){
                     JOptionPane.showMessageDialog(null, "La cédula no fue encontrada:");
                     band=true;
                     menu();
                 }
                 break;
             }
             case 3 -> {
                  cedula=Long.parseLong(JOptionPane.showInputDialog(null, "Digite la cédula: "));
                 for (Cuenta Cuenta:Cuentas){
                     if(cedula==Cuenta.getDNI()){
                         dinero=Double.parseDouble(JOptionPane.showInputDialog(null,"Digite el dinero que va a retirar:"));
                         Cuenta.retirar(dinero);
                         Cuenta.actusaldo();
                         
                         JOptionPane.showMessageDialog(null,"El dinero ha sido retirado.");
                         band=true;
                         menu();
                     }
                     else{
                         band=false;
                     }
                 }
                 if(band==false){
                     JOptionPane.showMessageDialog(null, "La cédula no fue encontrada:");
                     band=true;
                     menu();
                 }
                 break;
             }
             case 4 -> {
                cedula=Long.parseLong(JOptionPane.showInputDialog(null, "Digite la cédula: "));
                for(Cuenta Cuenta:Cuentas){ 
                    if(cedula==Cuenta.getDNI()){
                     JOptionPane.showMessageDialog(null, Cuenta.datos());
                     menu();
                    }      
                }
                break;
             }
             case 5 -> {
                for(Cuenta Cuenta:Cuentas){
                     JOptionPane.showMessageDialog(null, Cuenta.datos());
                     
                 }
                menu();
               break;
             }
             case 6 -> {
             JOptionPane.showMessageDialog(null,"Adiossssssssss");
             break;
             }
             default -> {
                 JOptionPane.showMessageDialog(null,"La opción es del 1 al 6.");
                 menu();
            }
         }
     }
}

