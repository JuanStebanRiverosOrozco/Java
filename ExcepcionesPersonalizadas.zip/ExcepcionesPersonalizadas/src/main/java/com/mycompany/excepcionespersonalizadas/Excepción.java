package com.mycompany.excepcionespersonalizadas;
public class Excepción extends Exception{
    public Excepción(String mensaje){
        super (mensaje);
    }
    
}
