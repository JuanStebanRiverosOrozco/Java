package com.mycompany.excepcionespersonalizadas;

import java.util.Scanner;

public class ExcepcionesPersonalizadas {

    public static void main(String[] args) throws Excepción{
        
        int edad;
        Scanner scanner = new Scanner(System.in);
        System.out.println("Ingrese su edad:");
        edad=scanner.nextInt();
        
        

        try{
        if(edad>=18){
            System.out.println("BIENVENIDO eres mayor de edad.");
        }
        else{
            throw new Excepción("EDAD NO PERMITIDA, eres menor de edad.");
        }
        }
        catch(Exception ex){
            System.out.println(ex.getMessage());
        }
    }
}
