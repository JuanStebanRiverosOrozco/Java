
package Snake1;
public class Main {
    public static void main(String[] args) {
        SnakePrincipal objeto = new SnakePrincipal();
        objeto.setVisible(true);
        
    }
}
