package calculadora;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class Calculadora extends JFrame {

    public Calculadora() {
        setTitle("Bienvenido");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centrar la ventana
        setLayout(new BorderLayout()); // Layout para la ventana principal
        inicializarMenuPrincipal(); // Llama al método que crea el menú
        revalidate(); // Refresca el layout para asegurar la visibilidad
        repaint();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Calculadora calculadora = new Calculadora();
            calculadora.setVisible(true);
        });
    }

    private void inicializarMenuPrincipal() {
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(2, 2, 10, 10));

        JButton btnSuma = new JButton("Suma");
        JButton btnResta = new JButton("Resta");
        JButton btnMultiplicacion = new JButton("Multiplicación");
        JButton btnDivision = new JButton("División");

        // Agregamos los ActionListeners para cada botón, abriendo la ventana de cada operación
        btnSuma.addActionListener(e -> abrirOperacion("Suma"));
        btnResta.addActionListener(e -> abrirOperacion("Resta"));
        btnMultiplicacion.addActionListener(e -> abrirOperacion("Multiplicación"));
        btnDivision.addActionListener(e -> abrirOperacion("División"));

        panel.add(btnSuma);
        panel.add(btnResta);
        panel.add(btnMultiplicacion);
        panel.add(btnDivision);

        add(panel, BorderLayout.CENTER); // Agrega el panel al centro de la ventana
    }

    private void abrirOperacion(String operacion) {
        JFrame ventanaOperacion = new JFrame(operacion);
        ventanaOperacion.setSize(400, 300);
        ventanaOperacion.setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(6, 1, 10, 10));

        JLabel labelOperacion = new JLabel("Operación: " + operacion, SwingConstants.CENTER);
        JTextField campoNumero1 = new JTextField();
        JTextField campoNumero2 = new JTextField();
        JButton btnCalcular = new JButton("Calcular");

        // Configuración del label de resultado con texto blanco y fondo gris oscuro
        JLabel labelResultado = new JLabel("Resultado: ", SwingConstants.CENTER);
        labelResultado.setForeground(Color.WHITE); // Texto blanco
        labelResultado.setBackground(Color.BLACK); // Fondo gris oscuro
        labelResultado.setOpaque(true); // Hace que el fondo sea visible

        JButton btnRegresar = new JButton("Regresar");

        panel.add(labelOperacion);
        panel.add(campoNumero1);
        panel.add(campoNumero2);
        panel.add(btnCalcular);
        panel.add(labelResultado);
        panel.add(btnRegresar);

        // ActionListener para calcular el resultado de la operación seleccionada
        btnCalcular.addActionListener((ActionEvent e) -> {
            try {
                double numero1 = Double.parseDouble(campoNumero1.getText());
                double numero2 = Double.parseDouble(campoNumero2.getText());
                double resultado = 0;

                switch (operacion) {
                    case "Suma":
                        resultado = numero1 + numero2;
                        break;
                    case "Resta":
                        resultado = numero1 - numero2;
                        break;
                    case "Multiplicación":
                        resultado = numero1 * numero2;
                        break;
                    case "División":
                        if (numero2 != 0) {
                            resultado = numero1 / numero2;
                        } else {
                            labelResultado.setText("Error: División por cero");
                            return;
                        }
                        break;
                }
                labelResultado.setText("Resultado: " + resultado);
            } catch (NumberFormatException ex) {
                labelResultado.setText("Error: Entrada no válida");
            }
        });

        // ActionListener para regresar al menú principal
        btnRegresar.addActionListener(e -> ventanaOperacion.dispose());

        ventanaOperacion.add(panel);
        ventanaOperacion.setVisible(true);
    }
}
