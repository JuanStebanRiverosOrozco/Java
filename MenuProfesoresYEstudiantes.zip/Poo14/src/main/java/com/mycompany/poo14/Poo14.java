package com.mycompany.poo14;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Poo14 {

    public static void main(String[] args) {
        menu(); 
    }
static ArrayList<Profesor> Profe=new ArrayList<>();
static ArrayList<Estudiante> Estudi=new ArrayList<>();
        
        
 public static void menu(){
         int opc;
         Profesor Prof=new Profesor();
         Estudiante Estu=new Estudiante();
         
         opc=Integer.parseInt(JOptionPane.showInputDialog(null, """
                                                                Digite una opción
                                                                1. Registrar Profesor:
                                                                2. Registrar Estudiante:
                                                                3. Ver datos de un Profesor:
                                                                4. Ver datos de un Estudiante:
                                                                5. Ver datos de todos los Profesores:
                                                                6. Ver datos de todos los Estudiantes:
                                                                7. Eliminar un Profesor:
                                                                8. Eliminar un Estudiante:
                                                                9. Salir:
                                                                """));
         switch(opc){
             case 1:{
                 Prof.setNombre(String.format(JOptionPane.showInputDialog(null,"Digite cuál es el Nombre: ")));
                 Prof.setEdad(Integer.parseInt(JOptionPane.showInputDialog(null,"Digite cuál es su Edad: ")));
                 Prof.setMateria(String.format(JOptionPane.showInputDialog(null,"Digite cuál es su Materia asignada: ")));
                 Prof.setCurso(Double.parseDouble(JOptionPane.showInputDialog(null,"Digite cuál es su Curso asignado: ")));
                 Prof.setSalario(Double.parseDouble(JOptionPane.showInputDialog(null,"Digite cuál es su Salario: ")));
                
                 Profe.add(Prof);
                 JOptionPane.showMessageDialog(null, "El Profesor ha sido registrado.");
                 menu();
                 break;
             }
             case 2:{
                 Estu.setNombre(String.format(JOptionPane.showInputDialog(null,"Digite cuál es su Nombre: ")));
                 Estu.setEdad(Integer.parseInt(JOptionPane.showInputDialog(null,"Digite cuál es su Edad: ")));
                 Estu.setMateria(String.format(JOptionPane.showInputDialog(null,"Digite cuál Materia le tocó: ")));
                 Estu.setCurso(Double.parseDouble(JOptionPane.showInputDialog(null,"Digite cuál es su Curso: ")));
                 Estu.setPromedio(Double.parseDouble(JOptionPane.showInputDialog(null,"Digite cuál es su Promedio: ")));
                 
                 Estudi.add(Estu);
                 JOptionPane.showMessageDialog(null, "El Estudiante ha sido registrado.");
                 menu();
                 break;        
             }
             case 3:{
                 String a;
                 boolean band=true;
                 a = JOptionPane.showInputDialog(null,"Digite cuál es el Nombre del Profesor: ");
                 for (Profesor Pro:Profe){
                     if(a.equals(Pro.getNombre())){
                         if (band==true){
                            Pro.datos(); 
                            menu();
                         }  
                    }
                      else if(band==false){
                        JOptionPane.showMessageDialog(null,"El Nombre del Profesor no existe.");
                     
                        }  
                 }
                 menu();
                 break;
             }
             case 4:{
                 String b;
                 boolean band=true;
                 b = JOptionPane.showInputDialog(null,"Digite cuál es el Nombre del Estudiante: ");
                 for (Estudiante Es:Estudi){
                     if(b.equals(Es.getNombre())){
                        if (band==true){
                            Es.datos();
                            menu();
                        }
                    }
                      else if(band==false){
                         JOptionPane.showMessageDialog(null,"El Nombre del Estudiante no existe.");
                     }
                 }
                    menu();
                    break;
             }
             case 5:{
                for(Profesor Pro:Profe){
                     Pro.datos();
                }
                menu();
                break;                  
             }
             case 6:{
                 for(Estudiante Es:Estudi){
                     Es.datos();
                 }
                 menu();
                 break;
             }       
             case 7:{
                 String c; 
                 c = JOptionPane.showInputDialog(null,"Digite el Profesor que va a eliminar :");
               
             for(Profesor Pro:Profe){
                   if(c.equals(Pro.getNombre())){
                       Profe.remove(Pro);
                       JOptionPane.showMessageDialog(null,"El Profesor fue eliminado."); 
                       menu(); 
                    }  
               } 
             menu();
             break;
             }
             case 8:{
                 String d; 
                 d = JOptionPane.showInputDialog(null,"Digite el Estudiante que va a eliminar :");
               
             for(Estudiante Es:Estudi){
                   if(d.equals(Es.getNombre())){
                       
                       Estudi.remove(Es);
                       JOptionPane.showMessageDialog(null,"El Estudiante fue eliminado."); 
                       menu(); 
                   }                 
               }     
                 break;
             }
             case 9:{
                 JOptionPane.showMessageDialog(null, "Byee.");
                 System.exit(0);
             }
             default:{
                 JOptionPane.showMessageDialog(null,"Error la opción no existe.");
                 menu();
            }
             
         }
 }
}
