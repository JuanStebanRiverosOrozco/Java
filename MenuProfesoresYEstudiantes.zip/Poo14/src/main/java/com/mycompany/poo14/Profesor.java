
package com.mycompany.poo14;

import javax.swing.JOptionPane;

public class Profesor {

    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getMateria() {
        return materia;
    }

    public void setMateria(String materia) {
        this.materia = materia;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public double getCurso() {
        return curso;
    }

    public void setCurso(double curso) {
        this.curso = curso;
    }


    private String nombre;
    private String materia;
    private int edad;
    private double salario;
    private double curso;
 
    
    
    public Profesor(){
        
    }
    
 
    public Profesor(String nombre,String materia,int edad,double curso,double salario,int ususario){
       this.nombre=nombre; 
        this.materia=materia;
        this.edad=0;
        this.curso=0.0;
        this.salario=0.0;
        
    }    
       public Profesor(String nombre,String materia,int edad,double curso,int usuario){
        this.nombre=nombre; 
        this.materia=materia;
        this.edad=0;
        this.curso=0.0;    
        
    }
    
    public void datos(){
        JOptionPane.showMessageDialog(null, "El Nombre es: "+nombre+"\n"+
                                                        "La Edad es: "+edad+"\n"+
                                                        "La Materia es: "+materia+"\n"+
                                                        "El Curso es: "+curso+"\n"+
                                                        "El Salario es: "+salario);               
    }
    
}
