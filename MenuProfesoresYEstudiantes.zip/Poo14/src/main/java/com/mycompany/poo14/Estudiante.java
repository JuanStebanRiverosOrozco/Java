package com.mycompany.poo14;

import javax.swing.JOptionPane;

public class Estudiante extends Profesor{
    
    String nombre;
    String materia;
    int edad;
    double curso;
 
    private double promedio;   

    public double getPromedio() {
        return promedio;
    }

    public void setPromedio(double promedio) {
        this.promedio = promedio;
    }
     
    public Estudiante(){
        
    }
    public Estudiante(String nombre,String materia,int edad,double curso,int usuario,double promedio){
        super(nombre,materia,edad,curso,usuario);
        this.promedio=0.0;
    }
    @Override
        public void datos(){
        JOptionPane.showMessageDialog(null, "El Nombre es: "+getNombre()+"\n"+
                                                        "La Edad es: "+getEdad()+"\n"+
                                                        "La Materia es: "+getMateria()+"\n"+
                                                        "El Curso es: "+getCurso()+"\n"+
                                                        "El Promedio es: "+promedio);                                 
    }
}
