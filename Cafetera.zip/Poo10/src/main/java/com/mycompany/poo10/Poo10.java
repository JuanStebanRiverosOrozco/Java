package com.mycompany.poo10;

import javax.swing.JOptionPane;

public class Poo10{
    private double _capacidadActual;
    private double _capacidadMaxima;

    public Poo10() {
        _capacidadMaxima = 1000;
        _capacidadActual = 0;
    }

    public Poo10(double capacidadMaxima) {
        _capacidadMaxima = capacidadMaxima;
        _capacidadActual = capacidadMaxima;
    }

    public Poo10(double capacidadMaxima, double capacidadActual) {
        _capacidadMaxima = capacidadMaxima;
        if (capacidadActual > capacidadMaxima) {
            _capacidadActual = capacidadMaxima;
        } else {
            _capacidadActual = capacidadActual;
        }
    }

    public double getCapacidadActual() {
        return _capacidadActual;
    }

    public void llenarCafetera() {
        _capacidadActual = _capacidadMaxima;
    }

    public void servirTaza(double cantidad) {
        if (cantidad <= _capacidadActual) {
            _capacidadActual -= cantidad;
            JOptionPane.showMessageDialog(null, "Se sirvió una taza de " + cantidad + " gramos.");
        } else {
            JOptionPane.showMessageDialog(null, "El café es insuficiente para llenar la taza.");
            _capacidadActual = 0;
        }
    }

    public void vaciarCafetera() {
        _capacidadActual = 0;
    }

    public void agregarCafe(double cantidad) {
        if (_capacidadActual + cantidad <= _capacidadMaxima) {
            _capacidadActual += cantidad;
        } else {
            JOptionPane.showMessageDialog(null, "La Cafetera está llenita.");
            _capacidadActual = _capacidadMaxima;
        }
    }

    public static void main(String[] args) {
        Poo10 Cafetera = new Poo10();
        int opcion = 0;

        while (opcion != 5) {
            String menu = """
                          \tCafeteria
                          1. Ver capacidad actual:
                          2. Llenar cafetera:
                          3. Servir taza:
                          4. Agregar café:
                          5. Salir:
                          """;

            opcion = Integer.parseInt(JOptionPane.showInputDialog(menu));

            switch (opcion) {
                case 1:
                    JOptionPane.showMessageDialog(null, "La Capacidad actual es: " + Cafetera.getCapacidadActual()+" gramos.");
                    break;
                case 2:
                    Cafetera.llenarCafetera();
                    JOptionPane.showMessageDialog(null, "La cafetera ha sido rellenada.");
                    break;
                case 3:
                    double cantidadAServir = Double.parseDouble(JOptionPane.showInputDialog("Ingrese la cantidad que quiere servir: "));
                    Cafetera.servirTaza(cantidadAServir);
                    break;
                case 4:
                    double cantidadAAgregar = Double.parseDouble(JOptionPane.showInputDialog("Ingrese la cantidad que quiere agregar: "));
                    if (cantidadAAgregar <= 1000) {
                        Cafetera.agregarCafe(cantidadAAgregar);
                    } else {
                        JOptionPane.showMessageDialog(null, "No puedes agregar más de 1000 gramos.");
                    }
                    break;
                case 5:
                    JOptionPane.showMessageDialog(null, "Byeee.");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "La opción no existe.");
                    break;
            }
        }
    }
}