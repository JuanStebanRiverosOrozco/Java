/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package operaciones;

import javax.swing.JOptionPane;

/**
 *
 * @author Lenovo
 */
public class Operaciones {
    
    public static void main(String[] args) {
       menu();
    }
        public static void menu(){
       Operaciones op = new Operaciones();
       int opc;
       double num1, num2, result;
       opc=Integer.parseInt(JOptionPane.showInputDialog(null,""" 
                                                                  Ingrese una opcion
                                                                         1. suma
                                                                         2. resta
                                                                         3. multiplicación
                                                                         4. división
                                                                         5. salir                                                                  
                                                                  """));
        
        switch (opc){
            case 1 ->{
            num1=Double.parseDouble(JOptionPane.showInputDialog(null,"Digite el 1er número:"));
            num2=Double.parseDouble(JOptionPane.showInputDialog(null,"Digite el 2do número:"));
            result = num1+num2;
            JOptionPane.showMessageDialog(null, "Resultado de la Suma: " + result);
            break;
            }  
            case 2->{
            num1=Double.parseDouble(JOptionPane.showInputDialog(null,"Digite el 1er número:"));
            num2=Double.parseDouble(JOptionPane.showInputDialog(null,"Digite el 2do número:"));
            result = num1-num2;
            JOptionPane.showMessageDialog(null, "Resultado de la Resta: " + result);
            break;
            }
            case 3->{
            num1=Double.parseDouble(JOptionPane.showInputDialog(null,"Digite el 1er número:"));
            num2=Double.parseDouble(JOptionPane.showInputDialog(null,"Digite el 2do número:"));
            result = num1*num2;
            JOptionPane.showMessageDialog(null, "Resultado de la Multiplicación: " + result);
            break;
            }
            case 4->{
            num1=Double.parseDouble(JOptionPane.showInputDialog(null,"Digite el 1er número:"));
            num2=Double.parseDouble(JOptionPane.showInputDialog(null,"Digite el 2do número:"));    
            result = num1/num2;
            JOptionPane.showMessageDialog(null, "Resultado de la División: " + result);
            break;
            }
            case 5->{
            JOptionPane.showMessageDialog(null, "Saliendo del programa...");
            System.exit(0);
            break;
            }
            default->{
            JOptionPane.showMessageDialog(null, "Opción inválida.");
            break;
            }                
        }
        menu();
    }
}
